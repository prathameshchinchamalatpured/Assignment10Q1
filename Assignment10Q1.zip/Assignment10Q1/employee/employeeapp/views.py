from django.shortcuts import render,HttpResponse,redirect
from .models import Employee
# Create your views here.
"""
def index(request):
    return render(request,'employeeresult.html')
"""

def create_employee(request):    
    e=Employee.objects.create(empid=102,fname="Ram1",lname="Esx",age=23,address="Pune")
    e.save()
    return HttpResponse("Object saved")


def employeeapp_search(request,appname,field_name,lookup_element,search_element):
    #filter_element = ""
    if lookup_element == 'startswith':
        filter_element = f"{field_name}__startswith" 
    elif lookup_element=='contains':
        filter_element = f"{field_name}__contains"
    elif lookup_element=='lte':
        filter_element = f"{field_name}__lte"
    else:
        pass
    
    filter_query= {filter_element:search_element} 
    
    emp = Employee.objects.filter(**filter_query)
    
    for e in emp:
        print(e.fname+" "+e.lname)
   
    
    
    context={
        'employees':emp,
        'fieldname':field_name,
        'lookupelement':lookup_element,
        'filterelement':filter_element,
        'searchelement':search_element
    }

    
    return render(request,'employeeresult.html',context)    


