from django.urls import path
from employeeapp import views

urlpatterns = [
    path('',views.create_employee),
    path('<str:appname>/<str:field_name>/<str:lookup_element>/<str:search_element>',views.employeeapp_search)
]
